Two archived copies of the contest leader site.

mirror-2026-10-26: the 47 page site that first reached number one on Oct 26.
mirror-2026-10-27: the 119 page site that has held number one since Nov 1.

Open index.html inside either folder. See the README.txt in each folder.
